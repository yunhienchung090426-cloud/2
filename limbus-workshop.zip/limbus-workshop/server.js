// 림버스 인격 제작소 - 백엔드 서버
// API 키는 .env(환경 변수)에서만 읽으며, 브라우저로는 절대 전달되지 않습니다.
require('dotenv').config();
const path = require('path');
const express = require('express');
const rateLimit = require('express-rate-limit');

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const API_KEY = (process.env.GEMINI_API_KEY || '').trim();
const PRIMARY_MODEL = (process.env.GEMINI_MODEL || 'gemini-2.5-flash').trim();
const FALLBACKS = (process.env.GEMINI_FALLBACK_MODELS || '')
  .split(',').map((s) => s.trim()).filter(Boolean);
const MODELS = [PRIMARY_MODEL, ...FALLBACKS.filter((m) => m !== PRIMARY_MODEL)];
const KEY_MISSING = !API_KEY || API_KEY.includes('여기에');

app.set('trust proxy', 1); // 배포 환경(프록시 뒤)에서 IP 제한이 올바르게 동작하도록
app.use(express.json({ limit: '100kb' }));
app.use(express.static(path.join(__dirname, 'public')));

// ---------- 허용 값 ----------
const SINNERS = ['이상', '파우스트', '돈키호테', '료슈', '뫼르소', '홍루',
  '히스클리프', '이스마엘', '로쟈', '싱클레어', '오티스', '그레고르'];
const EQUIPMENT = ['공방 장비', '날개 장비', 'E.G.O 장비', 'E.G.O 방어구',
  '의체', '특수 개조 장비', '기타 장비'];
const LENGTHS = {
  '보통': {
    maxTokens: 12000,
    guide: '한국어 약 5,000~8,000자. 하나의 완결된 이야기. 장면 3~4개, 핵심 사건 1개와 그에 따른 갈등, 분명한 결말.'
  },
  '장편': {
    maxTokens: 32000,
    guide: '한국어 약 12,000~20,000자. 장면 6~9개, 충분한 대화, 서로 맞물리는 사건 2~3개, 갈등의 고조와 해소.'
  },
  '매우 장편': {
    maxTokens: 64000,
    guide: '한국어 약 25,000자 이상, 가능한 한 출력 한도까지. 챕터 구분을 두고 복수의 사건과 인물 관계를 깊이 다루며, 각 장면이 인과적으로 이어지게 한다. 같은 묘사를 반복해서 분량을 채우지 말 것.'
  }
};

const clean = (v, max) => String(v == null ? '' : v).trim().slice(0, max);

// ---------- 입력 검증 ----------
function parseInput(body) {
  const b = body || {};
  const sinner = clean(b.sinner, 20);
  if (!SINNERS.includes(sinner)) return { error: '수감자를 선택해 주세요.' };

  const lengthKey = clean(b.length, 10);
  if (!LENGTHS[lengthKey]) return { error: '이야기 분량을 선택해 주세요.' };

  const equipment = (Array.isArray(b.equipment) ? b.equipment : [])
    .map((e) => clean(e, 20)).filter((e) => EQUIPMENT.includes(e));
  const hasEgo = equipment.includes('E.G.O 장비') || equipment.includes('E.G.O 방어구');

  return {
    data: {
      sinner,
      lengthKey,
      organization: clean(b.organization, 200),
      rank: clean(b.rank, 200),
      combatLevel: clean(b.combatLevel, 300),
      goal: clean(b.goal, 800),
      equipment,
      otherEquipment: equipment.includes('기타 장비') ? clean(b.otherEquipment, 400) : '',
      ego: hasEgo ? {
        name: clean(b.egoName, 200),
        ability: clean(b.egoAbility, 1500),
        trigger: clean(b.egoTrigger, 1500)
      } : null,
      appearance: b.useAppearance ? clean(b.appearance, 1500) : '',
      outfit: b.useOutfit ? clean(b.outfit, 1500) : ''
    }
  };
}

// ---------- 프롬프트 (서버 안에서만 관리) ----------
const SYSTEM_PROMPT = `당신은 《림버스 컴퍼니》(Project Moon) 세계관에 정통한 한국어 소설가이자 팬픽션 설정 보조자입니다.
사용자가 준 설정으로 '팬메이드 오리지널 인격' 이야기를 씁니다.

[절대 규칙]
1. 결과는 설정표나 요약문이 아니라 실제 소설이어야 합니다. 장면 묘사, 인물 간 대화, 사건, 갈등, 선택, 전개, 결말이 있어야 합니다.
2. 사용자가 입력한 설정(소속, 직위, 전투 수준, 장비, E.G.O 등)은 이야기의 핵심 설정입니다. 임의로 바꾸거나 뒤집지 마세요.
3. 사용자가 목표를 적지 않았다면 인물에게 세계를 구한다거나 복수를 한다는 식의 거창한 목표를 임의로 부여하지 마세요. 인물이 처한 상황과 일상적·개인적 동기 안에서 이야기를 이끄세요.
4. 선택된 장비는 모두 이야기에 등장시키되, 선택되지 않은 특수 장비를 새로 만들어 핵심 능력으로 쓰지 마세요.
5. E.G.O 설정이 있으면 사용자가 쓴 능력과 발현 계기를 요약하지 말고, 실제 사건과 장면을 통해 드러내세요. 능력의 핵심 내용을 바꾸지 마세요.
6. 외형 설정이 주어지지 않았다면 외모를 길게 묘사하지 마세요. 복장 설정이 주어지지 않았다면 복장을 길게 묘사하지 마세요. 주어진 경우에만 자연스럽게 반영하세요.
7. 원작의 기존 대사나 스토리를 길게 옮기지 말고, 새로운 장면과 대화를 창작하세요.
8. 원작 설정이 확실하지 않으면 공식 설정이라고 단정하지 마세요. 모르는 것은 모른다고 두고, 창작한 부분은 창작으로 취급하세요.
9. 분량을 늘리기 위해 같은 설명이나 문장을 반복하지 마세요.
10. 폭력은 원작 수준의 소설적 표현에 머무르고, 지나치게 잔혹하거나 선정적인 묘사는 피하세요.

[출력 형식 - 반드시 아래 마크다운 제목 구조를 지키세요]
# (이야기 제목)

## 이야기
(소설 본문. 도입부 → 여러 장면과 사건 → 갈등 → 결말. 필요하면 장면 구분선이나 소제목 사용)

## 이후 능력치와 수준
(이야기 이후 평가를 문장 또는 짧은 목록으로: 전투 능력 / 장비 숙련도 / 주요 강점 / 약점과 한계 / 전투에서의 특징 / 소속·등급에 따른 평가. 공식 수치나 게임 내부 능력치(숫자, 스탯)를 사실처럼 만들지 말고 서술형으로만 쓰세요.)

## 설정 메모
(세 부분으로 구분: '사용자 입력 설정' / '이번 이야기에서 새로 창작한 설정' / '원작과의 주의점'. 원작에서 확실하지 않은 부분과 원작과 충돌할 가능성이 있는 내용은 간단히 알려주세요.)`;

function buildUserPrompt(d) {
  const L = LENGTHS[d.lengthKey];
  const lines = [];
  lines.push('아래 설정으로 팬메이드 오리지널 인격 이야기를 작성하세요.', '');
  lines.push(`■ 수감자: ${d.sinner}`);
  lines.push(`■ 소속/조직: ${d.organization || '(미입력 - 임의로 거창한 소속을 만들지 말고 자연스럽게 처리)'}`);
  lines.push(`■ 세부 조직/직위/등급: ${d.rank || '(미입력)'}`);
  lines.push(`■ 전투 수준: ${d.combatLevel || '(미입력 - 과하게 강하게 설정하지 말 것)'}`);
  lines.push(`■ 목표: ${d.goal || '(미입력 - 거창한 목표를 임의로 부여하지 말 것)'}`);
  lines.push('');
  lines.push(`■ 선택한 장비: ${d.equipment.length ? d.equipment.join(', ') : '(선택 없음)'}`);
  if (d.otherEquipment) lines.push(`  - 기타 장비 내용: ${d.otherEquipment}`);
  if (d.ego) {
    lines.push('', '■ E.G.O 상세 설정');
    lines.push(`  - 이름: ${d.ego.name || '(미입력)'}`);
    lines.push(`  - 능력: ${d.ego.ability || '(미입력)'}`);
    lines.push(`  - 발현 이유/계기: ${d.ego.trigger || '(미입력)'}`);
  }
  lines.push('');
  lines.push(`■ 외형 묘사: ${d.appearance || '(없음 - 외형을 길게 묘사하지 말 것)'}`);
  lines.push(`■ 복장 묘사: ${d.outfit || '(없음 - 복장을 길게 묘사하지 말 것)'}`);
  lines.push('', `■ 이야기 분량: ${d.lengthKey}`, `  - ${L.guide}`);
  lines.push('', '지정된 출력 형식(제목 → ## 이야기 → ## 이후 능력치와 수준 → ## 설정 메모)을 반드시 지켜 끝까지 작성하세요.');
  return lines.join('\n');
}

// ---------- Gemini 호출 ----------
async function callGemini(model, d) {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`;
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 9 * 60 * 1000); // 최대 9분
  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-goog-api-key': API_KEY },
      signal: ctrl.signal,
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: SYSTEM_PROMPT }] },
        contents: [{ role: 'user', parts: [{ text: buildUserPrompt(d) }] }],
        generationConfig: {
          temperature: 1.0,
          maxOutputTokens: LENGTHS[d.lengthKey].maxTokens
        }
      })
    });
    const json = await res.json().catch(() => ({}));
    return { status: res.status, json };
  } finally {
    clearTimeout(timer);
  }
}

function extractText(json) {
  const cand = json && json.candidates && json.candidates[0];
  const parts = (cand && cand.content && cand.content.parts) || [];
  const text = parts.map((p) => p.text || '').join('').trim();
  return { text, finishReason: cand && cand.finishReason };
}

// ---------- 요청 제한 ----------
const limiter = rateLimit({
  windowMs: (Number(process.env.RATE_LIMIT_WINDOW_MIN) || 10) * 60 * 1000,
  max: Number(process.env.RATE_LIMIT_MAX) || 5,
  standardHeaders: true,
  legacyHeaders: false,
  handler: (req, res) => res.status(429).json({
    error: '요청이 너무 많습니다. 잠시 후 다시 시도해 주세요.'
  })
});

const inFlight = new Set(); // 같은 IP의 중복 요청 방지

app.get('/api/status', (req, res) => {
  res.json({ keyConfigured: !KEY_MISSING, model: PRIMARY_MODEL });
});

app.post('/api/generate', limiter, async (req, res) => {
  if (KEY_MISSING) {
    return res.status(500).json({
      error: 'API 키가 설정되지 않았습니다. 프로젝트 폴더의 .env 파일에 GEMINI_API_KEY=발급받은키 를 입력하고 서버를 다시 시작해 주세요. (자세한 방법은 README.md 참고)'
    });
  }
  const parsed = parseInput(req.body);
  if (parsed.error) return res.status(400).json({ error: parsed.error });

  const ip = req.ip;
  if (inFlight.has(ip)) {
    return res.status(409).json({ error: '이미 이야기를 생성하고 있습니다. 완료될 때까지 기다려 주세요.' });
  }
  inFlight.add(ip);

  try {
    let last = null;
    for (const model of MODELS) {
      let r;
      try {
        r = await callGemini(model, parsed.data);
      } catch (e) {
        if (e.name === 'AbortError') {
          return res.status(504).json({ error: '생성 시간이 너무 오래 걸려 중단되었습니다. 분량을 줄여 다시 시도해 주세요.' });
        }
        console.error('[Gemini 네트워크 오류]', e.message);
        return res.status(502).json({ error: 'AI 서버에 연결하지 못했습니다. 인터넷 연결을 확인하고 다시 시도해 주세요.' });
      }
      last = r;
      if (r.status === 404) { console.warn(`[모델 없음] ${model} → 다음 모델 시도`); continue; }
      break;
    }

    const { status, json } = last;
    if (status === 400 && /API key/i.test((json.error && json.error.message) || '')) {
      return res.status(500).json({ error: 'API 키가 올바르지 않습니다. 키를 다시 확인해 주세요.' });
    }
    if (status === 401 || status === 403) {
      return res.status(500).json({ error: 'API 키가 거부되었습니다. 키가 올바른지, Gemini API 사용이 허용되어 있는지 확인해 주세요.' });
    }
    if (status === 404) {
      return res.status(500).json({ error: `사용 가능한 모델을 찾지 못했습니다. .env의 GEMINI_MODEL 값을 확인해 주세요. (시도: ${MODELS.join(', ')})` });
    }
    if (status === 429) {
      return res.status(429).json({ error: 'AI 사용량 한도를 초과했습니다. 잠시 후 다시 시도해 주세요.' });
    }
    if (status !== 200) {
      console.error('[Gemini 오류]', status, JSON.stringify(json).slice(0, 500));
      return res.status(502).json({ error: `AI 요청에 실패했습니다. (코드 ${status}) 잠시 후 다시 시도해 주세요.` });
    }

    if (json.promptFeedback && json.promptFeedback.blockReason) {
      return res.status(422).json({ error: '입력한 설정이 AI 안전 필터에 걸려 생성되지 않았습니다. 표현을 조금 바꿔 다시 시도해 주세요.' });
    }
    const { text, finishReason } = extractText(json);
    if (!text) {
      return res.status(502).json({ error: 'AI가 빈 응답을 반환했습니다. 다시 시도해 주세요.', retry: true });
    }
    res.json({
      text,
      truncated: finishReason === 'MAX_TOKENS',
      finishReason: finishReason || null
    });
  } catch (e) {
    console.error('[서버 오류]', e);
    res.status(500).json({ error: '서버 내부 오류가 발생했습니다. 터미널의 오류 로그를 확인해 주세요.' });
  } finally {
    inFlight.delete(ip);
  }
});

const server = app.listen(PORT, () => {
  console.log(`림버스 인격 제작소 실행 중: http://localhost:${PORT}`);
  console.log(`모델: ${MODELS.join(' → ')}`);
  if (KEY_MISSING) console.warn('⚠ GEMINI_API_KEY가 설정되지 않았습니다. .env 파일을 확인하세요.');
});
server.requestTimeout = 0;      // 긴 생성 중 연결이 끊기지 않도록
server.headersTimeout = 65000;
